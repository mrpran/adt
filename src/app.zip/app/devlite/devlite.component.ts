import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-devlite',
  templateUrl: './devlite.component.html',
  styleUrls: ['./devlite.component.css']
})
export class DevliteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
