import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adt',
  templateUrl: './adt.component.html',
  styleUrls: ['./adt.component.css']
})
export class AdtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
